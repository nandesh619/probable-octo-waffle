# SSH + ADB Hub

A Windows desktop app (C# / WPF / .NET 8) that combines:

- **SSH + SFTP client** that **auto-connects on start**, with a GUI folder browser (upload, download, new folder, delete).
- **ADB panel** for managing **many Android devices at once** (Fire TV, Android TV boxes, tablets, phones).
- **Script runner** to run your own scripts from the PC on the **router (SSH)**, on **Android devices (ADB)**, or on the **PC itself**.

It was designed for an **OpenWrt router** (Dropbear SSH) plus several Android / Android TV devices, but it works with any SSH server and any ADB device.

> **Status:** version 0.2. Please read [Known limitations](#known-limitations).
>
> **New in 0.2:** per-device app manager, device nicknames and notes, router dashboard, one-click router config backup, script parameter forms and run history, system tray icon with start-minimized, and drag-and-drop for APKs and files.

---

## Contents

1. [Features](#features)
2. [Build on GitHub (no installs needed)](#build-on-github-no-installs-needed)
3. [Build locally](#build-locally)
4. [First run](#first-run)
5. [Router setup (OpenWrt)](#router-setup-openwrt)
6. [Using the app](#using-the-app)
7. [Scripts](#scripts)
8. [Where settings are stored / security](#where-settings-are-stored--security)
9. [Troubleshooting](#troubleshooting)
10. [Project structure](#project-structure)
11. [Known limitations](#known-limitations)
12. [Roadmap](#roadmap)

---

## Features

| Area | What it does |
|------|--------------|
| **SSH profiles** | Save several servers (host, port, user, key file, password). Passwords are encrypted with Windows DPAPI. |
| **Auto-connect** | Mark one profile as "Auto-connect on start"; it connects as soon as the app opens. |
| **Auto-reconnect** | Checks every 10 seconds and reconnects if the link drops (e.g. router reboot). Keep-alive packets every 30 s. |
| **Start with Windows** | One tick-box adds the app to your Windows startup list (current user only). |
| **Host key pinning** | On first connect the SHA256 fingerprint is shown and, if you accept, pinned. A changed key is refused. |
| **Folder browser (SFTP)** | Navigate (double-click, Up, type a path), upload, download, create folder, delete. Symlinks (e.g. `/var`) are followed. |
| **Console** | Run one-off commands on the router and watch the output live, with a Stop button. |
| **ADB device list** | Shows every device from `adb devices -l`, auto-refreshing every 5 s. Tick several devices to act on all of them at once. |
| **ADB over Wi-Fi** | Connect by IP:port, keep a saved list, "Connect all saved", and pair (Android 11+ wireless debugging). |
| **ADB actions** | Install APK, screenshot (saved to `Pictures\SshAdbHub`), reboot, run any `adb shell` command, on all ticked devices in parallel. |
| **Script runner** | Router (`sh`), Android (`sh` via ADB), or PC (`.ps1`, `.bat`, `.cmd`). Arguments, live output, Stop button, warning before destructive commands. |
| **App manager** | Lists every package on a device, filter by user/system/disabled/removed, then uninstall (for user 0), disable, enable, restore removed system apps, force-stop, clear data and export APKs. |
| **Nicknames and notes** | Give each device a name ("Bedroom Fire Stick") and notes. Saved devices that are offline stay in the list as `not connected`. |
| **Router dashboard** | Live cards for WAN status, IP, speed, router model, uptime, load, RAM, plus a Wi-Fi client table with signal, rates, hostname and IP. |
| **Config backup** | One click runs `sysupgrade -b` on the router, downloads the `.tar.gz` with a date stamp, and warns if no backup exists. |
| **Script parameters** | `{{placeholders}}` in scripts open a small form (last values remembered). |
| **Run history** | Every script run is saved (time, target, exit code, full output). |
| **Tray icon** | Close button hides to the tray, optional "start minimized", tray menu with Open / Connect / Exit. |
| **Drag and drop** | Drop an APK on a device row to install it; drop files or folders on the Files tab to upload; drop scripts on the script list to add them. |
| **Bundled ADB** | The GitHub build downloads Google's `platform-tools` and ships `adb.exe` inside the zip. Nothing to install. |

---

## Build on GitHub (no installs needed)

You do not need Visual Studio or .NET on your PC. GitHub compiles it for you.

1. Create a new repository on GitHub (private or public).
2. Upload **all files from this folder** keeping the structure (the `.github/workflows/build.yml` file must be at that exact path).
   - Easiest: install **GitHub Desktop**, or on the repo page choose **Add file -> Upload files** and drag the whole folder contents in.
3. Open the **Actions** tab. The **Build** workflow starts by itself on every push (you can also click **Run workflow**).
4. When it shows a green tick, open the run and download the **`SshAdbHub-win-x64`** artifact at the bottom.
5. Unzip it anywhere (for example `C:\Tools\SshAdbHub`) and run **`SshAdbHub.exe`**.

The zip contains:

```
SshAdbHub.exe          single-file, self-contained (no .NET install needed)
scripts\               sample scripts (copied, editable)
platform-tools\        adb.exe and friends (downloaded from Google during the build)
```

### Make a proper release (optional)

Push a version tag and the workflow also attaches the zip to a GitHub Release:

```
git tag v0.1.0
git push origin v0.1.0
```

### If the build fails

Open the failed run, click the red step, and copy the error text. Compile errors show the file name and line number. Fixing them is usually a one-line change.

---

## Build locally

Requirements: Windows 10/11 and the [.NET 8 SDK](https://dotnet.microsoft.com/download/dotnet/8.0).

```powershell
dotnet run --project SshAdbHub\SshAdbHub.csproj
```

Or produce the same single-file build as GitHub:

```powershell
dotnet publish SshAdbHub\SshAdbHub.csproj -c Release -r win-x64 --self-contained true `
  -p:PublishSingleFile=true -p:IncludeNativeLibrariesForSelfExtract=true -o publish
```

Locally there is no bundled ADB. Either install [platform-tools](https://developer.android.com/tools/releases/platform-tools) and put `adb` on your `PATH`, or pick `adb.exe` in the **ADB devices** tab with **Browse...**.

---

## First run

1. Click **Add** next to the profile box.
2. Fill in:
   - **Host / IP**: your router, usually `192.168.1.1`.
   - **Port**: `22`.
   - **Username**: `root` on OpenWrt.
   - **Key file** (optional) or **password**.
3. Tick **Auto-connect this profile on start** and, if you want, **Start with Windows**.
4. Click **Connect**. On the first connection a window shows the host key fingerprint. Compare it if you care, then click **Yes** to pin it.

Next time you start the app (or Windows), it connects by itself.

---

## Router setup (OpenWrt)

OpenWrt ships **Dropbear** as its SSH server. It supports **SSH and SCP, but not SFTP**. The folder browser needs SFTP, so install the SFTP server on the router once:

```sh
# OpenWrt 24.10 and older
opkg update
opkg install openssh-sftp-server

# newer snapshots that use apk instead of opkg
apk update
apk add openssh-sftp-server
```

Check which package manager you have by running `which opkg apk`.

If SFTP is missing, the app still connects: the **Console** and **Scripts** work, but the **Files** tab shows an error in the **Log** tab.

### Key-based login (recommended)

On your PC (PowerShell):

```powershell
ssh-keygen -t ed25519 -f $env:USERPROFILE\.ssh\router_ed25519
```

Copy the public key to the router. Dropbear reads `/etc/dropbear/authorized_keys` for root:

```powershell
type $env:USERPROFILE\.ssh\router_ed25519.pub | ssh root@192.168.1.1 "cat >> /etc/dropbear/authorized_keys"
```

In the profile dialog, pick `router_ed25519` (the file **without** `.pub`) as the key file.

Notes:

- The key must be in **OpenSSH format** (the format `ssh-keygen` produces). PuTTY `.ppk` files are not supported; convert them in PuTTYgen with *Conversions -> Export OpenSSH key*.
- If the key has a passphrase, enter it in the **Password** box of the profile.

### Which protocols does the router offer?

| Protocol | Port | Default on OpenWrt | Used by this app |
|----------|------|--------------------|------------------|
| SSH (Dropbear) | 22 | Yes | Console, scripts, connection |
| SCP | 22 | Yes (via Dropbear) | Not used |
| SFTP | 22 | No, install `openssh-sftp-server` | Folder browser |
| LuCI web UI (HTTP/HTTPS) | 80 / 443 | Yes (HTTP) | Not used yet |
| ubus JSON-RPC | 80 (`/ubus`) | Yes (with LuCI) | Not used yet |

Check what is actually listening on your router: `netstat -lntp` (run in the Console tab).

---

## Using the app

### Top bar

- **Profile box + Add / Edit / Delete**: manage SSH profiles.
- **Connect / Disconnect**: manual control. Disconnecting stops auto-reconnect until you connect again.
- **Auto-connect this profile on start**: only one profile can have this.
- **Auto-reconnect**: reconnects after a lost connection.
- **Start with Windows**.

### Files (SFTP) tab

- Double-click a folder to enter it. **Up** goes to the parent. Type a path and press Enter to jump.
- **Upload** sends files to the current folder. **Download** asks for a destination folder and saves the selected files.
- **Delete** removes files and **empty** folders (non-empty folders must be emptied first).

### Console (SSH) tab

Type a command, press Enter. Output streams live. **Stop** cancels the running command. This is a one-command-at-a-time console, not a full interactive terminal (no `vi`, no `top`).

### ADB devices tab

1. Make sure `adb.exe` is found (the box at the top shows which one is used).
2. **USB devices** appear automatically. Accept the "Allow USB debugging" prompt on the device if the state says `unauthorized`.
3. **Wi-Fi devices**: type `192.168.1.50:5555` (port 5555 is assumed if you omit it) and click **Connect**. Successful addresses are saved in the drop-down. **Connect all saved** reconnects all of them in one click.
4. **Android 11+ wireless debugging**: on the device open *Developer options -> Wireless debugging -> Pair device with pairing code*, then click **Pair...** and enter the pairing IP:port and the code. After that, connect using the IP:port shown on the main Wireless debugging screen.
5. Tick **Use** on one or more devices (state must be `device`). **Install APK**, **Screenshot**, **Reboot** and **Run on selected** act on every ticked device in parallel. If nothing is ticked, the highlighted row is used.

Fire TV and many Android TV boxes: enable *Settings -> My Fire TV -> Developer options -> ADB debugging* (and *Apps from unknown sources* for installs).

### Apps (ADB) tab

1. Choose a device in the **Device** box (only devices in state `device` appear) and click **Load apps**.
2. Use the filter box and the type drop-down (All / User / System / Disabled / Removed) to narrow the list, then tick the apps you want. **Tick all shown** only ticks what is currently visible, and actions only affect ticked apps that are visible.
3. Actions:
   - **Uninstall**: runs `pm uninstall --user 0`. For system apps this removes them for the main user only, the APK stays on the system partition, so it is reversible with **Restore removed** (`cmd package install-existing`).
   - **Disable** / **Enable**: `pm disable-user` / `pm enable`. A softer alternative to uninstalling.
   - **Force stop** and **Clear data**.
   - **Export APK...**: pulls the APK(s) of the ticked apps into a folder you choose (split APKs go into a sub-folder per package).
4. You are asked to confirm uninstall, disable and clear data. Removing essential system apps (launcher, setup wizard, Play services, etc.) can break the device, so disable first and test.

### Device nicknames and notes

In the **ADB devices** tab click a row, then **Rename / notes...**. The name appears in the device list, in output prefixes and in the Apps tab. Saved devices that are not currently connected show as `not connected`. **Connect all saved** reconnects every saved IP:port. **Forget** removes a saved device.

### Router dashboard tab

Connect to the router first. The tab shows:

- **WAN card**: connection state, IP address, protocol (for example `pppoe`), uptime, DNS, and live download/upload speed (measured between refreshes).
- **Router card**: model, hostname, OpenWrt release, uptime, load average, RAM bar.
- **Wi-Fi card** and **client table**: every associated device with hostname/IP (from DHCP leases), MAC, network name and band, signal in dBm with a quality label, and RX/TX rates. Sorted strongest first.

Set the **WAN interface** box if your WAN interface is not called `wan`. Auto-refresh runs every 5 seconds while the tab is open. The dashboard uses `ubus`, `ifstatus`, `jsonfilter` and `iwinfo`, which are present on a normal OpenWrt image.

#### Config backup

**Back up router config now** runs `sysupgrade -b /tmp/hub-backup.tar.gz` on the router, downloads the file to `Documents\SshAdbHub\backups\<profile>-backup-<date>.tar.gz` (using SFTP if available, otherwise streaming it over SSH), and deletes the temporary copy on the router. The tab shows when the last backup was taken and warns if there has never been one, or if it is older than 30 days. A script that contains `sysupgrade`, `firstboot`, `reboot` and similar also adds a warning to its confirmation box when no backup exists.

To restore: copy the file back to the router and run `sysupgrade -r backup.tar.gz && reboot`, or use LuCI under *System -> Backup / Flash Firmware -> Restore backup*.

### Run history tab

Every script run is stored in `%APPDATA%\SshAdbHub\history.json` (last 200 runs, output capped at 30,000 characters each). Select a row to see the full output; **Copy output** and **Clear history** are above the table.

### Tray icon

The app puts an icon in the system tray. With **Close button hides to tray** ticked (default), the X button hides the window and the app keeps running (auto-reconnect keeps working). Right-click the icon for **Open**, **Connect/Disconnect** and **Exit**. **Start minimized to tray** adds `--minimized` to the Windows startup entry so the app starts hidden at login (tick **Start with Windows** too).

### Drag and drop

| Drop onto | Result |
|-----------|--------|
| A device row (ADB tab) | `.apk` files are installed with `adb install -r`; any other file is copied to `/sdcard/Download/`. If you drop on empty space, the ticked devices are used. |
| The file list (Files tab) | Files and whole folders are uploaded to the folder you are viewing (needs SFTP). |
| The script list (Scripts tab) | `.sh`, `.ps1`, `.bat`, `.cmd` files are copied into the scripts folder. |

### Scripts tab

See the next section.

---

## Scripts

Put scripts in the **scripts** folder (the **Open** button opens it; **Change...** uses any other folder). Supported types:

| Extension | Runs on |
|-----------|---------|
| `.sh` | Router (via SSH) or Android (via ADB) |
| `.ps1`, `.bat`, `.cmd` | This PC |

### Header comments

The first lines of a script can tell the app where it should run and what it does:

```sh
#!/bin/sh
# target: router
# description: Prints uptime, load and Wi-Fi clients.
```

`target:` can be `router`, `android` or `pc`. For `.bat` use `REM target: pc`. The "Run on" box switches automatically when you select the script.

### Parameters (placeholders)

Write `{{name}}` or `{{name|default value}}` anywhere in a script. When you press **Run**, a small form asks for each distinct name, pre-filled with the value you used last time (or the default). Example:

```sh
# target: android
# description: Force-stops an app.
am force-stop {{package|com.netflix.ninja}}
```

Notes:

- The values are inserted into the script text **as typed** (no automatic quoting). Quote them in the script yourself where needed, for example `ping -c 4 "{{host|1.1.1.1}}"`.
- Only type values you trust; they are executed on the device.
- Names may contain letters, digits and underscores. A default cannot contain `}`.
- The **Arguments** box still works as well (`$1`, `$2` ...).
- For PC scripts a temporary copy with the values filled in is run and deleted afterwards.

### How each target works

- **Router**: the script text is sent as `sh -c '<script>' name arg1 arg2 ...` over SSH. Nothing is uploaded, so it works even without SFTP. Use **POSIX `sh`** (OpenWrt has BusyBox `ash`, not `bash`). Arguments from the **Arguments** box arrive as `$1`, `$2`, ...
- **Android**: the script is pushed to `/data/local/tmp/hub_script.sh` on every ticked device, run with `sh`, and removed afterwards. Without root you run as the `shell` user. Devices run in parallel and output lines are prefixed with the device serial.
- **PC**: PowerShell is started with `-ExecutionPolicy Bypass -File`. The environment variable **`HUB_ADB`** holds the path of the adb.exe the app uses, so PC scripts can call ADB on all your devices.

Line endings are converted to Unix (`LF`) automatically before sending, so scripts saved on Windows still work.

### Safety

- Before running, the script text is scanned for words like `reboot`, `sysupgrade`, `firstboot`, `rm -rf`, `mkfs`, `dd if=`, `mtd`, and you are asked to confirm.
- **Stop** kills the running command (SSH channel cancelled, or local process killed).
- Router scripts have a 10-minute timeout.
- Be careful with scripts that change network settings: a bad change can lock you out of the router. Keep a physical way to reset it.

### Included samples

| File | Target | Purpose |
|------|--------|---------|
| `router-info.sh` | router | Model, uptime, memory, WAN, Wi-Fi clients |
| `router-restart-wifi.sh` | router | `wifi reload` |
| `android-info.sh` | android | Model, Android version, battery, storage |
| `pc-adb-devices.ps1` | pc | Lists ADB devices using `HUB_ADB` |
| `android-force-stop.sh` | android | Force-stops an app (parameter: `package`) |
| `router-ping.sh` | router | Pings a host from the router (parameters: `count`, `host`) |

---

## Where settings are stored / security

- Settings file: `%APPDATA%\SshAdbHub\settings.json` (profiles, saved devices with names/notes, paths, last backup times, last used script parameters).
- Run history: `%APPDATA%\SshAdbHub\history.json`. It contains script output, so treat it as private.
- Router backups (`Documents\SshAdbHub\backups`) contain your router configuration, including Wi-Fi passwords and keys. Store them somewhere safe.
- **Passwords / key passphrases** are stored encrypted with **Windows DPAPI** for your Windows user account. They cannot be decrypted by another user or on another PC. They are not stored in plain text.
- **Host keys** are pinned per profile on first connect. If a server's key changes later, the connection is refused. To accept a legitimately changed key (for example after reflashing the router), **Edit** the profile and press OK; changing host or port also clears the pinned key.
- Use **key authentication** where possible.
- ADB over Wi-Fi has no encryption or login beyond the device's own authorisation prompt. Only use it on a trusted home network.
- This app only talks to the devices you configure. It does not scan your network.

---

## Troubleshooting

| Problem | Likely cause / fix |
|---------|--------------------|
| `Connect failed: ... Permission denied` | Wrong password, or the key is not in `/etc/dropbear/authorized_keys`. Make sure the key file is the private key and OpenSSH format. |
| `Connect failed: ... actively refused` / timeout | Wrong IP/port, router firewall, or Dropbear not listening. Test with `ssh root@192.168.1.1` in PowerShell. |
| Files tab empty, Log says "SFTP unavailable" | Install `openssh-sftp-server` on the router. |
| Host key refused | The server's key changed. If expected, edit the profile and press OK to clear the pin. |
| Key file error | Not OpenSSH format (PuTTY `.ppk`), or wrong passphrase. |
| `adb error: Could not start 'adb'` | adb.exe not found. Use the GitHub build (bundled) or **Browse...** to select it. |
| Device state `unauthorized` | Accept the USB/wireless debugging prompt on the device. |
| Device state `offline` | Reconnect: **Disconnect selected** then **Connect**, or toggle debugging on the device. |
| `adb install` fails | Check the message in the output; common: signature mismatch (uninstall first), not enough storage, or "unknown sources" disabled. |
| Android script: `Permission denied` | Non-root `shell` user cannot do that. Use a rooted device with `su -c` inside the script. |
| Dashboard shows `Not found` for WAN | Wrong interface name. Check `ifstatus wan` in the Console, or look at *Network -> Interfaces* in LuCI (PPPoE is usually still called `wan`). |
| Dashboard Wi-Fi table is empty | No station is connected, or `iwinfo` is missing. Run `iwinfo` in the Console tab to check. |
| Backup fails with `sysupgrade: not found` | The router is not running OpenWrt, or the PATH is limited. Try `which sysupgrade` in the Console tab. |
| Apps tab: `No packages returned` | The device is `unauthorized` or `offline`, or does not allow `pm` over ADB. |
| `Uninstall` says `Failure [DELETE_FAILED_DEVICE_POLICY_MANAGER]` | The app is protected by a device policy (some TV boxes). Use **Disable** instead. |
| Windows SmartScreen warning | The exe is unsigned. Click *More info -> Run anyway*, or build it yourself from this source. |

---

## Project structure

```
.
├── .github/workflows/build.yml    CI: restore, publish single-file exe, bundle adb, zip, upload artifact, release on tags
├── README.md
└── SshAdbHub/
    ├── SshAdbHub.csproj           .NET 8 WPF project (SSH.NET + ProtectedData)
    ├── App.xaml / App.xaml.cs     application start + global error box
    ├── MainWindow.xaml            UI (tabs: Files, Console, ADB devices, Scripts, Router dashboard, Apps, Run history, Log)
    ├── MainWindow.xaml.cs         startup, profiles, connect/reconnect, Files tab, Console tab
    ├── MainWindow.Adb.cs          ADB devices tab, nicknames, drag-and-drop
    ├── MainWindow.Apps.cs         app manager
    ├── MainWindow.Dashboard.cs    router dashboard + config backup (and the dashboard shell script)
    ├── MainWindow.Scripts.cs      scripts tab, placeholders, run history
    ├── MainWindow.Tray.cs         tray icon, start minimized, close-to-tray
    ├── ProfileDialog.xaml / .cs   add/edit SSH profile window
    ├── Dialogs.cs                 small input prompt
    ├── Models.cs                  SshProfile, AppSettings, AdbDevice, RemoteItem
    ├── SettingsStore.cs           JSON settings and history, DPAPI helpers, "start with Windows"
    ├── SshService.cs              SSH.NET: connect, host-key pinning, SFTP, streaming commands
    ├── AdbService.cs              adb discovery and device list
    ├── ProcRun.cs                 process runner with live output, shell quoting
    └── scripts/                   sample scripts copied next to the exe
```

---

## Known limitations

- **This version was written without being compiled on the author's side.** The GitHub Action is the first real build. If it reports compile errors, they will be small; paste the log to fix them.
- The Console tab is not a full terminal (no interactive programs).
- Recursive delete and recursive download of folders are not implemented (uploads of folders are).
- The tray icon uses the default executable icon. Add an `.ico` and `<ApplicationIcon>` in the csproj for a custom one.
- Only one SSH connection at a time (profiles are switchable).
- The dashboard needs OpenWrt tools (`ubus`, `jsonfilter`, `iwinfo`); it will not work on other firmware.
- The dashboard WAN speed is measured from interface counters and is only shown after the second refresh.
- The single-file exe is unsigned.

---

## Roadmap

Ideas, roughly in order of usefulness:

1. Android TV / Fire TV remote panel (D-pad, Home, Back, volume, text input) sending `input keyevent` to ticked devices.
2. Scheduled scripts and "run on connect" scripts per device.
3. Real terminal tab (xterm.js in WebView2).
4. Local pane next to the remote pane in the Files tab, and recursive download.
5. Network scan for devices listening on port 5555.
6. Port forwarding / tunnels (for example to the LuCI web UI).
7. Logcat viewer per device.
8. Router restore button and backup list.

---

## Third-party components

- [SSH.NET](https://github.com/sshnet/SSH.NET) (MIT) for SSH and SFTP.
- [Android SDK Platform-Tools](https://developer.android.com/tools/releases/platform-tools) (downloaded by the CI build, subject to Google's licence terms).

No licence file is included. Add one (for example MIT) before publishing the repository publicly.
